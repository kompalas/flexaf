# rm -rf alib-52
rm -rf csrc gate gate_simv.daidir logs reports tech_lib work_gate_lib 
rm gate_simv synopsys_sim.setup ucli.key verdi_config_file
rm sim/output.txt sim/top.fsdb